import Login from './Login'; 
/* import FundCollection from './components/FundCollection'; */
import './App.css';

function App() {
  return (
    <div className="App">
   < Login /> 
    { /* < FundCollection />  */}
    </div>
  );
}

export default App;
